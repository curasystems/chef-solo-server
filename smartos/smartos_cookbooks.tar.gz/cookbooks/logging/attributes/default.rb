default[:syslog][:server] = "localhost"
