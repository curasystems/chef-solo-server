#
# Cookbook Name:: zabbix
# Recipe:: default
#
# Copyright 2011, Joyent, Inc.
#
# All rights reserved - Do Not Redistribute
#
